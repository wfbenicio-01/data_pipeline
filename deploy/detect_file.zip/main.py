# detect_file
def lambda_handler(event, context):
    return {'function': 'detect_file', 'status': 'ok'}
