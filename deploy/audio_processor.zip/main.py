# audio_processor
def lambda_handler(event, context):
    return {'function': 'audio_processor', 'status': 'ok'}
