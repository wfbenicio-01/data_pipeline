# video_processor
def lambda_handler(event, context):
    return {'function': 'video_processor', 'status': 'ok'}
